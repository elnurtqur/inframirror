"""
Utility functions
"""