"""
Pydantic models for API requests and responses
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime
from enum import Enum


class PowerState(str, Enum):
    """VM power state enum"""
    POWERED_ON = "poweredOn"
    POWERED_OFF = "poweredOff"
    SUSPENDED = "suspended"


class GuestState(str, Enum):
    """VM guest state enum"""
    RUNNING = "running"
    NOT_RUNNING = "notRunning"
    UNKNOWN = "unknown"


class DiskInfo(BaseModel):
    """Disk information model"""
    label: str
    capacity_kb: int
    capacity_gb: float
    disk_mode: Optional[str] = None


class NetworkInfo(BaseModel):
    """Network information model"""
    label: str
    mac_address: Optional[str] = None
    connected: Optional[bool] = None
    network_name: Optional[str] = None


class DatastoreInfo(BaseModel):
    """Datastore information model"""
    name: str
    type: str
    capacity_gb: float
    free_space_gb: float


class VMTag(BaseModel):
    """VM tag model"""
    tag_id: str
    tag_name: Optional[str] = None
    tag_description: Optional[str] = None
    category_id: Optional[str] = None
    category_name: Optional[str] = None
    category_description: Optional[str] = None
    category_cardinality: Optional[str] = None


class VirtualMachine(BaseModel):
    """Virtual Machine model"""
    name: str
    mobid: str
    uuid: Optional[str] = None
    instance_uuid: Optional[str] = None
    power_state: Optional[str] = None
    guest_os: Optional[str] = None
    vm_version: Optional[str] = None
    annotation: Optional[str] = None
    created_date: Optional[datetime] = None
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    
    # Hardware
    cpu_count: Optional[int] = None
    cpu_cores_per_socket: Optional[int] = None
    memory_mb: Optional[int] = None
    memory_gb: Optional[float] = None
    
    # Storage
    disks: List[DiskInfo] = Field(default_factory=list)
    
    # Network
    networks: List[NetworkInfo] = Field(default_factory=list)
    
    # Guest
    guest_state: Optional[str] = None
    guest_os_full_name: Optional[str] = None
    guest_hostname: Optional[str] = None
    tools_status: Optional[str] = None
    tools_version: Optional[str] = None
    ip_address: Optional[str] = None
    guest_ip_addresses: List[str] = Field(default_factory=list)
    
    # Infrastructure
    host_name: Optional[str] = None
    datastores: List[DatastoreInfo] = Field(default_factory=list)
    resource_pool: Optional[str] = None
    folder_name: Optional[str] = None
    
    # Tags
    tags: List[Dict[str, str]] = Field(default_factory=list)
    tags_jira_asset: List[Dict[str, str]] = Field(default_factory=list)

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }


class JiraVirtualMachine(BaseModel):
    """Jira Virtual Machine model"""
    name: str
    jira_object_id: Optional[str] = None
    jira_object_key: Optional[str] = None
    vm_name: Optional[str] = None
    dns_name: Optional[str] = None
    
    # Network
    ip_address: Optional[str] = None
    secondary_ip: Optional[str] = None
    secondary_ip2: Optional[str] = None
    
    # Hardware
    cpu_count: Optional[int] = None
    memory_gb: Optional[float] = None
    memory_mb: Optional[int] = None
    disk_gb: Optional[int] = None
    
    # Infrastructure
    resource_pool: Optional[str] = None
    datastore: Optional[str] = None
    esxi_cluster: Optional[str] = None
    esxi_host: Optional[str] = None
    esxi_port_group: Optional[str] = None
    
    # Management
    site: Optional[str] = None
    description: Optional[str] = None
    jira_ticket: Optional[str] = None
    criticality_level: Optional[str] = None
    created_by: Optional[str] = None
    
    # System
    operating_system: Optional[str] = None
    platform: Optional[str] = None
    kubernetes_cluster: Optional[str] = None
    
    # Backup
    need_backup: Optional[str] = None
    backup_type: Optional[str] = None
    need_monitoring: Optional[str] = None
    
    # Responsible user
    responsible_ttl: Optional[Dict[str, str]] = None
    
    # Tags
    tags: List[Dict[str, str]] = Field(default_factory=list)
    tags_jira_asset: List[Dict[str, str]] = Field(default_factory=list)
    
    # Metadata
    created_date: Optional[datetime] = None
    updated_date: Optional[datetime] = None
    last_updated: datetime = Field(default_factory=datetime.utcnow)
    data_source: str = "jira_asset_management"

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }


class MissingVM(BaseModel):
    """Missing VM model for VMs in vCenter but not in Jira"""
    vm_name: str
    jira_asset_payload: Dict[str, Any]
    debug_info: Dict[str, Any]
    vm_summary: Dict[str, Any]
    status: str = "pending_creation"
    created_date: datetime = Field(default_factory=datetime.utcnow)
    source: str = "vcenter_diff_processor"

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda dt: dt.isoformat()
        }


class VCenterConfig(BaseModel):
    """vCenter configuration model"""
    host: str = Field(..., description="vCenter server hostname or IP")
    username: str = Field(..., description="vCenter username")
    password: str = Field(..., description="vCenter password")
    port: int = Field(443, description="vCenter port (default: 443)")


class JiraConfig(BaseModel):
    """Jira configuration model"""
    api_url: str = Field(..., description="Jira Asset Management API URL")
    token: str = Field(..., description="Jira Bearer token")
    object_type_id: str = Field("3191", description="VM Object Type ID")
    object_schema_id: str = Field("242", description="Object Schema ID")
    cookie: Optional[str] = Field(None, description="Session cookie (optional)")


class CollectionRequest(BaseModel):
    """VM collection request model"""
    vcenter_config: Optional[VCenterConfig] = Field(None, description="vCenter connection settings")
    batch_size: Optional[int] = Field(50, ge=1, le=200, description="VMs per batch")
    max_processes: Optional[int] = Field(8, ge=1, le=20, description="Maximum parallel processes")


class JiraCollectionRequest(BaseModel):
    """Jira VM collection request model"""
    jira_config: Optional[JiraConfig] = Field(None, description="Jira connection settings")
    batch_size: Optional[int] = Field(50, ge=1, le=200, description="VMs per batch")
    max_processes: Optional[int] = Field(8, ge=1, le=20, description="Maximum parallel processes")


class DiffProcessRequest(BaseModel):
    """VM diff processing request model"""
    jira_config: Optional[JiraConfig] = Field(None, description="Jira connection settings")


class CollectionResponse(BaseModel):
    """VM collection response model"""
    status: str
    message: str
    task_id: Optional[str] = None
    total_vms: Optional[int] = None
    processed_vms: Optional[int] = None
    errors: Optional[int] = None
    processing_time: Optional[float] = None


class VMListResponse(BaseModel):
    """VM list response model"""
    status: str
    message: str
    total_count: int
    vms: List[VirtualMachine]


class JiraVMListResponse(BaseModel):
    """Jira VM list response model"""
    status: str
    message: str
    total_count: int
    vms: List[JiraVirtualMachine]


class MissingVMListResponse(BaseModel):
    """Missing VM list response model"""
    status: str
    message: str
    total_count: int
    vms: List[MissingVM]


class DeleteResponse(BaseModel):
    """Delete response model"""
    status: str
    message: str
    deleted_count: int


class DiffProcessResponse(BaseModel):
    """Diff process response model"""
    status: str
    message: str
    total_vcenter_vms: Optional[int] = None
    total_jira_vms: Optional[int] = None
    missing_vms_count: Optional[int] = None
    processed_missing_vms: Optional[int] = None
    errors: Optional[int] = None
    processing_time: Optional[float] = None


class BatchResult(BaseModel):
    """Batch processing result model"""
    batch_id: int
    processed: int
    errors: int
    message: str


class ProcessingStatus(BaseModel):
    """Processing status model"""
    task_id: str
    status: str
    progress: Optional[Dict[str, Any]] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None