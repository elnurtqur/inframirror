"""
Pydantic models
"""