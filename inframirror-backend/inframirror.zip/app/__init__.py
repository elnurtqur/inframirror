"""
VMware Collector FastAPI Application
"""