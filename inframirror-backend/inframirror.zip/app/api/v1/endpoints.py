"""
API endpoints for VMware Collector
"""

import logging
from typing import Optional
from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from fastapi.responses import JSONResponse

from app.models.models import (
    CollectionRequest, 
    CollectionResponse, 
    VMListResponse, 
    DeleteResponse,
    VirtualMachine,
    JiraCollectionRequest,
    JiraVirtualMachine,
    JiraVMListResponse,
    DiffProcessRequest,
    DiffProcessResponse,
    MissingVM,
    MissingVMListResponse
)
from app.services.processing_service import ProcessingService
from app.services.jira_processing_service import JiraProcessingService
from app.services.diff_service import DiffService
from app.services.database_service import DatabaseService
from app.utils.utils import create_error_response, create_success_response

logger = logging.getLogger(__name__)

router = APIRouter()

# Service instances
processing_service = ProcessingService()
jira_processing_service = JiraProcessingService()
diff_service = DiffService()
database_service = DatabaseService()


@router.post("/collect-vms", response_model=CollectionResponse)
async def collect_vms(
    background_tasks: BackgroundTasks,
    request: CollectionRequest = CollectionRequest()
):
    """
    Collect VMs from vCenter and write to database
    """
    try:
        logger.info("VM collection started")
        
        # Extract vCenter configuration from request
        vcenter_config = None
        if request.vcenter_config:
            vcenter_config = {
                'host': request.vcenter_config.host,
                'username': request.vcenter_config.username,
                'password': request.vcenter_config.password,
                'port': request.vcenter_config.port
            }
        
        # Background task function
        def run_collection():
            return processing_service.collect_vms(
                vcenter_host=vcenter_config['host'] if vcenter_config else None,
                vcenter_username=vcenter_config['username'] if vcenter_config else None,
                vcenter_password=vcenter_config['password'] if vcenter_config else None,
                vcenter_port=vcenter_config['port'] if vcenter_config else None,
                batch_size=request.batch_size,
                max_processes=request.max_processes
            )
        
        # Run immediately (sync)
        result = run_collection()
        
        if result['status'] == 'success':
            return CollectionResponse(
                status="success",
                message=result['message'],
                total_vms=result['total_vms'],
                processed_vms=result['processed_vms'],
                errors=result['errors'],
                processing_time=result['processing_time']
            )
        else:
            raise HTTPException(
                status_code=500,
                detail=result['message']
            )
            
    except Exception as e:
        logger.error(f"VM collection error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"VM collection error: {str(e)}"
        )


@router.post("/collect-vms-async", response_model=CollectionResponse)
async def collect_vms_async(
    background_tasks: BackgroundTasks,
    request: CollectionRequest = CollectionRequest()
):
    """
    Collect VMs from vCenter (async) - as background task
    """
    try:
        logger.info("VM collection (async) started")
        
        # Extract vCenter configuration from request
        vcenter_config = None
        if request.vcenter_config:
            vcenter_config = {
                'host': request.vcenter_config.host,
                'username': request.vcenter_config.username,
                'password': request.vcenter_config.password,
                'port': request.vcenter_config.port
            }
        
        # Add as background task
        background_tasks.add_task(
            processing_service.collect_vms,
            vcenter_config['host'] if vcenter_config else None,
            vcenter_config['username'] if vcenter_config else None,
            vcenter_config['password'] if vcenter_config else None,
            vcenter_config['port'] if vcenter_config else None,
            request.batch_size,
            request.max_processes
        )
        
        return CollectionResponse(
            status="accepted",
            message="VM collection background task started. Check logs for progress."
        )
            
    except Exception as e:
        logger.error(f"VM collection async error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"VM collection async error: {str(e)}"
        )


@router.post("/collect-jira-vms", response_model=CollectionResponse)
async def collect_jira_vms(
    background_tasks: BackgroundTasks,
    request: JiraCollectionRequest = JiraCollectionRequest()
):
    """
    Collect VMs from Jira Asset Management and write to database
    """
    try:
        logger.info("Jira VM collection started")
        
        # Extract Jira configuration from request
        jira_config = None
        if request.jira_config:
            jira_config = {
                'api_url': request.jira_config.api_url,
                'token': request.jira_config.token,
                'object_type_id': request.jira_config.object_type_id,
                'object_schema_id': request.jira_config.object_schema_id,
                'cookie': request.jira_config.cookie or ''
            }
        
        # Background task function
        def run_jira_collection():
            return jira_processing_service.collect_jira_vms(
                api_url=jira_config['api_url'] if jira_config else None,
                token=jira_config['token'] if jira_config else None,
                object_type_id=jira_config['object_type_id'] if jira_config else None,
                object_schema_id=jira_config['object_schema_id'] if jira_config else None,
                cookie=jira_config['cookie'] if jira_config else None,
                batch_size=request.batch_size,
                max_processes=request.max_processes
            )
        
        # Run immediately (sync)
        result = run_jira_collection()
        
        if result['status'] == 'success':
            return CollectionResponse(
                status="success",
                message=result['message'],
                total_vms=result['total_vms'],
                processed_vms=result['processed_vms'],
                errors=result['errors'],
                processing_time=result['processing_time']
            )
        else:
            raise HTTPException(
                status_code=500,
                detail=result['message']
            )
            
    except Exception as e:
        logger.error(f"Jira VM collection error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Jira VM collection error: {str(e)}"
        )


@router.post("/collect-jira-vms-async", response_model=CollectionResponse)
async def collect_jira_vms_async(
    background_tasks: BackgroundTasks,
    request: JiraCollectionRequest = JiraCollectionRequest()
):
    """
    Collect VMs from Jira Asset Management (async) - as background task
    """
    try:
        logger.info("Jira VM collection (async) started")
        
        # Extract Jira configuration from request
        jira_config = None
        if request.jira_config:
            jira_config = {
                'api_url': request.jira_config.api_url,
                'token': request.jira_config.token,
                'object_type_id': request.jira_config.object_type_id,
                'object_schema_id': request.jira_config.object_schema_id,
                'cookie': request.jira_config.cookie or ''
            }
        
        # Add as background task
        background_tasks.add_task(
            jira_processing_service.collect_jira_vms,
            jira_config['api_url'] if jira_config else None,
            jira_config['token'] if jira_config else None,
            jira_config['object_type_id'] if jira_config else None,
            jira_config['object_schema_id'] if jira_config else None,
            jira_config['cookie'] if jira_config else None,
            request.batch_size,
            request.max_processes
        )
        
        return CollectionResponse(
            status="accepted",
            message="Jira VM collection background task started. Check logs for progress."
        )
            
    except Exception as e:
        logger.error(f"Jira VM collection async error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Jira VM collection async error: {str(e)}"
        )


@router.post("/process-vm-diff", response_model=DiffProcessResponse)
async def process_vm_diff(
    background_tasks: BackgroundTasks,
    request: DiffProcessRequest = DiffProcessRequest()
):
    """
    Process VM diff between vCenter and Jira - find missing VMs
    """
    try:
        logger.info("VM diff processing started")
        
        # Extract Jira configuration from request
        jira_config = None
        if request.jira_config:
            jira_config = {
                'api_url': request.jira_config.api_url,
                'token': "token_here",
                'object_type_id': request.jira_config.object_type_id,
                'object_schema_id': request.jira_config.object_schema_id,
                #'cookie': request.jira_config.cookie or ''
            }
        
        # Background task function
        def run_diff_process():
            return diff_service.process_vm_diff(
                api_url=jira_config['api_url'] if jira_config else None,
                token=jira_config['token'] if jira_config else None,
                object_type_id=jira_config['object_type_id'] if jira_config else None,
                object_schema_id=jira_config['object_schema_id'] if jira_config else None,
                #cookie=jira_config['cookie'] if jira_config else None
            )
        
        # Run immediately (sync)
        result = run_diff_process()
        
        if result['status'] == 'success':
            return DiffProcessResponse(
                status="success",
                message=result['message'],
                total_vcenter_vms=result['total_vcenter_vms'],
                total_jira_vms=result['total_jira_vms'],
                missing_vms_count=result['missing_vms_count'],
                processed_missing_vms=result['processed_missing_vms'],
                errors=result['errors'],
                processing_time=result['processing_time']
            )
        else:
            raise HTTPException(
                status_code=500,
                detail=result['message']
            )
            
    except Exception as e:
        logger.error(f"VM diff processing error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"VM diff processing error: {str(e)}"
        )


@router.post("/process-vm-diff-async", response_model=DiffProcessResponse)
async def process_vm_diff_async(
    background_tasks: BackgroundTasks,
    request: DiffProcessRequest = DiffProcessRequest()
):
    """
    Process VM diff between vCenter and Jira (async) - as background task
    """
    try:
        logger.info("VM diff processing (async) started")
        
        # Extract Jira configuration from request
        jira_config = None
        if request.jira_config:
            jira_config = {
                'api_url': request.jira_config.api_url,
                'token': request.jira_config.token,
                'object_type_id': request.jira_config.object_type_id,
                'object_schema_id': request.jira_config.object_schema_id,
                'cookie': request.jira_config.cookie or ''
            }
        
        # Add as background task
        background_tasks.add_task(
            diff_service.process_vm_diff,
            jira_config['api_url'] if jira_config else None,
            jira_config['token'] if jira_config else None,
            jira_config['object_type_id'] if jira_config else None,
            jira_config['object_schema_id'] if jira_config else None,
            jira_config['cookie'] if jira_config else None
        )
        
        return DiffProcessResponse(
            status="accepted",
            message="VM diff processing background task started. Check logs for progress."
        )
            
    except Exception as e:
        logger.error(f"VM diff processing async error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"VM diff processing async error: {str(e)}"
        )


@router.get("/get-all-vms-from-db", response_model=VMListResponse)
async def get_all_vms_from_db(
    skip: int = Query(0, ge=0, description="Number of VMs to skip"),
    limit: int = Query(1000, ge=1, le=5000, description="Maximum number of VMs"),
    search: Optional[str] = Query(None, description="Search query"),
    tag_category: Optional[str] = Query(None, description="Tag category"),
    tag_value: Optional[str] = Query(None, description="Tag value")
):
    """
    Get all VMs from database (vCenter collection)
    """
    try:
        logger.info(f"Retrieving VMs from database (skip={skip}, limit={limit})")
        
        # Based on search parameters
        if search:
            vms = await database_service.search_vms(search, limit)
            total_count = len(vms)  # Exact count is difficult for search
        elif tag_category and tag_value:
            vms = await database_service.get_vms_by_tag(tag_category, tag_value, limit)
            total_count = len(vms)
        else:
            vms = await database_service.get_all_vms(skip, limit)
            total_count = await database_service.get_vm_count()
        
        # Convert to Pydantic models
        vm_models = []
        for vm_data in vms:
            try:
                vm_model = VirtualMachine(**vm_data)
                vm_models.append(vm_model)
            except Exception as e:
                logger.warning(f"VM model conversion error: {e}")
                continue
        
        logger.info(f"Retrieved {len(vm_models)} VMs")
        
        return VMListResponse(
            status="success",
            message=f"Retrieved {len(vm_models)} VMs",
            total_count=total_count,
            vms=vm_models
        )
        
    except Exception as e:
        logger.error(f"Error retrieving VMs: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error retrieving VMs: {str(e)}"
        )


@router.get("/get-all-jira-vms-from-db", response_model=JiraVMListResponse)
async def get_all_jira_vms_from_db(
    skip: int = Query(0, ge=0, description="Number of VMs to skip"),
    limit: int = Query(1000, ge=1, le=5000, description="Maximum number of VMs")
):
    """
    Get all Jira VMs from database
    """
    try:
        logger.info(f"Retrieving Jira VMs from database (skip={skip}, limit={limit})")
        
        vms = await database_service.get_all_jira_vms(skip, limit)
        total_count = await database_service.get_jira_vm_count()
        
        # Convert to Pydantic models
        vm_models = []
        for vm_data in vms:
            try:
                vm_model = JiraVirtualMachine(**vm_data)
                vm_models.append(vm_model)
            except Exception as e:
                logger.warning(f"Jira VM model conversion error: {e}")
                continue
        
        logger.info(f"Retrieved {len(vm_models)} Jira VMs")
        
        return JiraVMListResponse(
            status="success",
            message=f"Retrieved {len(vm_models)} Jira VMs",
            total_count=total_count,
            vms=vm_models
        )
        
    except Exception as e:
        logger.error(f"Error retrieving Jira VMs: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error retrieving Jira VMs: {str(e)}"
        )


@router.get("/get-all-missing-vms-from-db", response_model=MissingVMListResponse)
async def get_all_missing_vms_from_db(
    skip: int = Query(0, ge=0, description="Number of VMs to skip"),
    limit: int = Query(1000, ge=1, le=5000, description="Maximum number of VMs")
):
    """
    Get all missing VMs from database (VMs in vCenter but not in Jira)
    """
    try:
        logger.info(f"Retrieving missing VMs from database (skip={skip}, limit={limit})")
        
        vms = await database_service.get_all_missing_vms(skip, limit)
        total_count = await database_service.get_missing_vm_count()
        
        # Convert to Pydantic models
        vm_models = []
        for vm_data in vms:
            try:
                vm_model = MissingVM(**vm_data)
                vm_models.append(vm_model)
            except Exception as e:
                logger.warning(f"Missing VM model conversion error: {e}")
                continue
        
        logger.info(f"Retrieved {len(vm_models)} missing VMs")
        
        return MissingVMListResponse(
            status="success",
            message=f"Retrieved {len(vm_models)} missing VMs",
            total_count=total_count,
            vms=vm_models
        )
        
    except Exception as e:
        logger.error(f"Error retrieving missing VMs: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error retrieving missing VMs: {str(e)}"
        )


@router.delete("/delete-all-vms-from-db", response_model=DeleteResponse)
async def delete_all_vms_from_db():
    """
    Delete all VMs from database (vCenter collection)
    """
    try:
        logger.info("Deleting all VMs...")
        
        deleted_count = await database_service.delete_all_vms()
        
        logger.info(f"Deleted {deleted_count} VMs")
        
        return DeleteResponse(
            status="success",
            message=f"Successfully deleted {deleted_count} VMs",
            deleted_count=deleted_count
        )
        
    except Exception as e:
        logger.error(f"Error deleting VMs: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting VMs: {str(e)}"
        )


@router.delete("/delete-all-jira-vms-from-db", response_model=DeleteResponse)
async def delete_all_jira_vms_from_db():
    """
    Delete all Jira VMs from database
    """
    try:
        logger.info("Deleting all Jira VMs...")
        
        deleted_count = await database_service.delete_all_jira_vms()
        
        logger.info(f"Deleted {deleted_count} Jira VMs")
        
        return DeleteResponse(
            status="success",
            message=f"Successfully deleted {deleted_count} Jira VMs",
            deleted_count=deleted_count
        )
        
    except Exception as e:
        logger.error(f"Error deleting Jira VMs: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting Jira VMs: {str(e)}"
        )


@router.delete("/delete-all-missing-vms-from-db", response_model=DeleteResponse)
async def delete_all_missing_vms_from_db():
    """
    Delete all missing VMs from database
    """
    try:
        logger.info("Deleting all missing VMs...")
        
        deleted_count = await database_service.delete_all_missing_vms()
        
        logger.info(f"Deleted {deleted_count} missing VMs")
        
        return DeleteResponse(
            status="success",
            message=f"Successfully deleted {deleted_count} missing VMs",
            deleted_count=deleted_count
        )
        
    except Exception as e:
        logger.error(f"Error deleting missing VMs: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error deleting missing VMs: {str(e)}"
        )


@router.get("/vm/{identifier}")
async def get_vm_by_identifier(identifier: str):
    """
    Get single VM by UUID or MobID
    """
    try:
        # First try UUID
        vm = await database_service.get_vm_by_uuid(identifier)
        
        # If not found by UUID, try MobID
        if not vm:
            vm = await database_service.get_vm_by_mobid(identifier)
        
        if not vm:
            raise HTTPException(
                status_code=404,
                detail=f"VM not found: {identifier}"
            )
        
        # Convert to Pydantic model
        vm_model = VirtualMachine(**vm)
        
        return create_success_response(
            data=vm_model,
            message="VM found successfully"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"VM search error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"VM search error: {str(e)}"
        )


@router.get("/statistics")
async def get_vm_statistics():
    """
    Get VM statistics
    """
    try:
        stats = await database_service.get_vm_statistics()
        
        return create_success_response(
            data=stats,
            message="Statistics retrieved successfully"
        )
        
    except Exception as e:
        logger.error(f"Statistics error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Statistics error: {str(e)}"
        )


@router.get("/jira-statistics")
async def get_jira_vm_statistics():
    """
    Get Jira VM statistics
    """
    try:
        stats = await database_service.get_jira_vm_statistics()
        
        return create_success_response(
            data=stats,
            message="Jira VM statistics retrieved successfully"
        )
        
    except Exception as e:
        logger.error(f"Jira VM statistics error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Jira VM statistics error: {str(e)}"
        )


@router.get("/collection-status")
async def get_collection_status():
    """
    Get collection status
    """
    try:
        vcenter_status = await processing_service.get_collection_status()
        jira_status = await jira_processing_service.get_jira_collection_status()
        missing_vm_count = await database_service.get_missing_vm_count()
        
        combined_status = {
            'vcenter': vcenter_status,
            'jira': jira_status,
            'missing_vms_count': missing_vm_count
        }
        
        return create_success_response(
            data=combined_status,
            message="Collection status retrieved"
        )
        
    except Exception as e:
        logger.error(f"Collection status error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Collection status error: {str(e)}"
        )


@router.get("/health")
async def health_check():
    """
    Health check endpoint
    """
    try:
        # Check database connection
        vm_count = await database_service.get_vm_count()
        jira_vm_count = await database_service.get_jira_vm_count()
        missing_vm_count = await database_service.get_missing_vm_count()
        
        return {
            "status": "healthy",
            "database": "connected",
            "vcenter_vm_count": vm_count,
            "jira_vm_count": jira_vm_count,
            "missing_vm_count": missing_vm_count,
            "timestamp": "2024-01-01T00:00:00Z"
        }
        
    except Exception as e:
        logger.error(f"Health check error: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "database": "disconnected",
                "error": str(e)
            }
        )